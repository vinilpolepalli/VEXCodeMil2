
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here


/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
void drive(double distance, int speed)
{
  TopLeftMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomLeftMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  TopRightMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomRightMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct);
}
void turnLeft(double distance, int speed)
{
  TopLeftMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomLeftMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  TopRightMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomRightMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct);

}
void turnRight(double distance, int speed)
{
  TopLeftMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomLeftMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  TopRightMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomRightMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct);
  

}

void driveReverse(double distance, int speed)
{
  TopLeftMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomLeftMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  TopRightMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomRightMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct);
}

void wingsOnOff(int b){
  while (true)
  {
    if (b==1)
    {
      RightWing.set(true);
      LeftWing.set(true);
    }

    else if (b==0){
      RightWing.set(false);
      LeftWing.set(false);
    }
  }
}



void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  
  drive(1.15,95); // knocks ball over to other side with matchload
  driveReverse(1.15,95); // reverses and comes back
  /*
  drive(0.9, 95); How long it takes to travel 1 square
  turnLeft(0.35, 95); 90 degree turn left
  turnRight(0.35,95); 90 degree turn right
  */
  driveReverse(1.72, 95);
  wingsOnOff(1);
  drive(1.72, 95);
  wingsOnOff(0);
  turnLeft(0.7, 95);
  drive(2.3, 95);
  turnRight(0.7, 95);
  wingsOnOff(1);
  drive(1.3, 95);
  wait(0.25,timeUnits::sec);
  driveReverse(1.3, 95);
  wingsOnOff(0);
  driveReverse(1.15,95);
  turnRight(0.7, 95);
  drive(2.75,95);
  turnLeft(0.7, 95);
  drive(1.2,95);
  turnRight(0.25,95);
  wingsOnOff(1);
  


}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
int intake(){
  while(true){
    while(Controller1.ButtonR1.pressing()){
      Intake.spin(forward, 100, percent);
    }
    while(Controller1.ButtonR2.pressing()){
      Intake.spin(reverse, 100, percent);
    }
    Intake.stop(hold);
  }
}
int wings(){
  while(true){
    while(Controller1.ButtonA.pressing()){
      RightWing.set(true);
      LeftWing.set(true);
    }
    while(Controller1.ButtonX.pressing()){
      RightWing.set(false);
      LeftWing.set(false);
    }
  }
}
int shoot(){
  while(true){
    while (Controller1.ButtonL1.pressing())
    {
      cata.spin(forward,75,percent);
    }
    cata.stop(hold);
  }
}
void usercontrol(void) {
  // User control code here, inside the loop
  cata.setVelocity(75, percentUnits::pct);
  thread w (wings);
  thread i (intake);
  thread s (shoot);
  while (1) {
    while (true) {
      // Tank drive control
      // Set the velocity of the left wheels based on the vertical position of
      // the left joystick
      
      
      TopLeftMotor.setVelocity(Controller1.Axis3.position(), percent);
      TopRightMotor.setVelocity(Controller1.Axis3.position(), percent);
      // Set the velocity of the right wheels based on the vertical position of
      // the right joystick
      BottomRightMotor.setVelocity(Controller1.Axis2.position(), percent);
      BottomLeftMotor.setVelocity(Controller1.Axis2.position(), percent);
      // Spin the left and right wheels forward based on their set velocities
      TopLeftMotor.spin(forward);
      TopRightMotor.spin(forward);
      BottomLeftMotor.spin(forward);
      BottomRightMotor.spin(forward);
      // Shooter control
      
  
      // Check if the top-left trigger (ButtonL1) is pressed
      
      



      vex::task::sleep(20); // Sleep to prevent wasted resources
    }
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Run the pre-autonomous function
  pre_auton();

  // Set up callbacks for autonomous and driver control periods
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Prevent main from exiting with an infinite loop
  while (true) {
    vex::task::sleep(100); // Sleep to prevent wasted resources

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // .....................................
    // ...................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
    Competition.autonomous(autonomous);
    Competition.drivercontrol(usercontrol);

    // Run the pre-autonomous function.
    pre_auton();

    // Prevent main from exiting with an infinite loop.
    while (true) {
      wait(100, msec);
    }
  }
}
