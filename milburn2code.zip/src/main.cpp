
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here


/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
void driveforward(double distance, int speed)
{
  leftMotorA.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct);
  leftMotorB.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct);
  rightMotorA.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct);
  rightMotorB.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct);
}
void DF(double distance, int speed){
  leftMotorA.setPosition(0, degrees);
  while(leftMotorA.position(degrees)<distance){
    leftMotorA.spin(forward, speed, percent);
    leftMotorB.spin(forward, speed, percent);
    rightMotorA.spin(forward, speed, percent);
    rightMotorB.spin(forward, speed, percent);
  }
  leftMotorA.stop(hold);
  rightMotorA.stop(hold);
  leftMotorB.stop(hold);
  rightMotorB.stop(hold);

}
void turnLeft(double distance, int speed)
{
  rightMotorA.setPosition(0, degrees);
  while(rightMotorA.position(degrees)<distance){
    leftMotorA.spin(reverse, speed, percent);
    leftMotorB.spin(reverse, speed, percent);
    rightMotorA.spin(forward, speed, percent);
    rightMotorB.spin(forward, speed, percent);
  }
  leftMotorA.stop(hold);
  rightMotorA.stop(hold);
  leftMotorB.stop(hold);
  rightMotorB.stop(hold);

}
void turnRight(double distance, int speed)
{
  leftMotorA.spinFor(distance, rotationUnits::deg, speed, velocityUnits::pct);
  leftMotorB.spinFor(distance, rotationUnits::deg, speed, velocityUnits::pct);
  rightMotorA.spinFor(-distance, rotationUnits::deg, speed, velocityUnits::pct);
  rightMotorB.spinFor(-distance, rotationUnits::deg, speed, velocityUnits::pct);
  

}

void driveReverse(double distance, int speed)
{
  leftMotorA.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct);
  leftMotorB.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct);
  rightMotorA.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct);
  rightMotorB.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct);
}

void IntakeBall(int revolutions)
{
  Intake.spinFor(1, rotationUnits::rev, 95, velocityUnits::pct);
}




void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  turnRight(100,100);
  DF(900, 100);
  
  
  


}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
int intake(){
  while(true){
    while(Controller1.ButtonR1.pressing()){
      Intake.spin(forward, 95, percent);
    }
    while(Controller1.ButtonR2.pressing()){
      Intake.spin(reverse, 95, percent);
    }
    Intake.stop(hold);
  }
}
/*
int wings(){
  while(true){
    while(Controller1.ButtonA.pressing()){
      RightWing.set(true);
      LeftWing.set(true);
    }
    while(Controller1.ButtonX.pressing()){
      RightWing.set(false);
      LeftWing.set(false);
    }
  }
}
*/

void usercontrol(void) {
  // User control code here, inside the loop
  cata.setVelocity(100, percentUnits::pct);
  thread i (intake);
  
  
  while (1) {
    int a = 1;
    while (true) {
      // Tank drive control
      // Set the velocity of the left wheels based on the vertical position of
      // the left joystick
      
      
      leftMotorA.setVelocity(Controller1.Axis3.position(), percent);
      leftMotorB.setVelocity(Controller1.Axis3.position(), percent);
      // Set the velocity of the right wheels based on the vertical position of
      // the right joystick
      rightMotorA.setVelocity(Controller1.Axis2.position(), percent);
      rightMotorB.setVelocity(Controller1.Axis2.position(), percent);
      // Spin the left and right wheels forward based on their set velocities
      leftMotorA.spin(forward);
      leftMotorB.spin(forward);
      rightMotorA.spin(forward);
      rightMotorB.spin(forward);
      // Shooter control
      
      if (Controller1.ButtonL1.pressing())
      {
        a+=1;
      }
      else if (Controller1.ButtonL2.pressing())
      {
        a-=1;
      }

      if (a == 2){
        cata.spin(forward);
      }
      else if (a==1)
      {
        cata.stop(brakeType::coast);
      }
      
  
      // Check if the top-left trigger (ButtonL1) is pressed
      
      



      vex::task::sleep(20); // Sleep to prevent wasted resources
    }
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Run the pre-autonomous function
  pre_auton();

  // Set up callbacks for autonomous and driver control periods
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Prevent main from exiting with an infinite loop
  while (true) {
    vex::task::sleep(100); // Sleep to prevent wasted resources

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // .....................................
    // ...................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
    Competition.autonomous(autonomous);
    Competition.drivercontrol(usercontrol);

    // Run the pre-autonomous function.
    pre_auton();

    // Prevent main from exiting with an infinite loop.
    while (true) {
      wait(100, msec);
    }
  }
}
